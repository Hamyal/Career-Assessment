'use client';

/**
 * Full-screen conversational chatbot UI — advanced premium styling.
 * One-question-at-a-time as chat messages; same scoring and backend.
 */

import { useState, useCallback, useRef, useEffect } from 'react';
import Link from 'next/link';
import { questions, getOptionMap, getOptionLabels, getChatPrompt } from '@/questions';
import styles from './assessment-chat.module.css';

const TOTAL = questions.length;

type ResponseState = Record<number, { selected_options: string[]; custom_text?: string }>;

type ChatMessage =
  | { role: 'assistant'; content: string; questionId?: number; isTransition?: boolean }
  | { role: 'user'; content: string };

function formatUserAnswer(
  qId: number,
  r: { selected_options: string[]; custom_text?: string } | undefined,
  getOptionLabelsForQ: (qId: number, optionIds: string[]) => { id: string; label: string }[]
): string {
  if (!r) return '';
  const optionMap = getOptionMap();
  const ids = optionMap[qId] ? Object.keys(optionMap[qId]) : [];
  const labels = getOptionLabelsForQ(qId, ids);
  if (r.selected_options?.length) {
    const optionPart = r.selected_options
      .map((id) => labels.find((l) => l.id === id)?.label ?? id)
      .filter(Boolean)
      .join(' · ') || '';
    const note = (r.custom_text ?? '').trim();
    return note ? `${optionPart}${optionPart ? ' · ' : ''}Note: ${note}` : optionPart;
  }
  if (qId === 5 && r.custom_text) return 'Photo uploaded';
  if (qId === 53 && r.custom_text) return 'Resume uploaded';
  return (r.custom_text ?? '').trim() || '';
}

export default function AssessmentPage() {
  const [step, setStep] = useState(0);
  const [responses, setResponses] = useState<ResponseState>(() => {
    const init: ResponseState = {};
    questions.forEach((q) => {
      init[q.id] = { selected_options: [] };
    });
    return init;
  });
  const completionSubmitted = useRef(false);
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'loading' | 'done' | 'error'>('idle');
  const [pdfUrl, setPdfUrl] = useState<string | null>(null);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [emailStatus, setEmailStatus] = useState<'unknown' | 'sent' | 'skipped' | 'failed'>('unknown');
  const [photoFileUrl, setPhotoFileUrl] = useState<string | null>(null);
  const [resumeFileUrl, setResumeFileUrl] = useState<string | null>(null);
  const [uploadingPhoto, setUploadingPhoto] = useState(false);
  const [uploadingResume, setUploadingResume] = useState(false);
  const [aiTransitions, setAiTransitions] = useState<Record<number, string>>({});
  const [submitTrigger, setSubmitTrigger] = useState(0);
  const idempotencyKeyRef = useRef<string | null>(null);
  const lastSessionIdRef = useRef<string | null>(null);
  const [lastSessionIdForRetry, setLastSessionIdForRetry] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const question = questions[step] ?? questions[0];
  const progress = ((step + 1) / TOTAL) * 100;
  const optionMap = getOptionMap();
  const optionIds = question.scored && optionMap[question.id] ? Object.keys(optionMap[question.id]) : [];
  const optionsWithLabels = getOptionLabels(question.id, optionIds);
  const currentResponse = responses[question.id] ?? { selected_options: [] };
  const selected = currentResponse.selected_options;
  const customText = currentResponse.custom_text ?? '';

  const scrollToBottom = useCallback(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [step, scrollToBottom]);

  const handleSelect = useCallback(
    (optionId: string) => {
      if (!question.scored) return;
      setResponses((prev) => {
        const next = { ...prev };
        const r = next[question.id] ?? { selected_options: [] };
        let newSelected: string[];
        if (question.multi_select) {
          if (r.selected_options.includes(optionId)) {
            newSelected = r.selected_options.filter((x) => x !== optionId);
          } else if (r.selected_options.length >= 2) {
            newSelected = r.selected_options;
          } else {
            newSelected = [...r.selected_options, optionId];
          }
        } else {
          newSelected = [optionId];
        }
        next[question.id] = { ...r, selected_options: newSelected };
        return next;
      });
    },
    [question.id, question.scored, question.multi_select]
  );

  const handleTextChange = useCallback((value: string) => {
    setResponses((prev) => ({
      ...prev,
      [question.id]: {
        ...prev[question.id],
        selected_options: prev[question.id]?.selected_options ?? [],
        custom_text: value,
      },
    }));
  }, [question.id]);

  const handleFileChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>, qId: number) => {
      const file = e.target.files?.[0];
      const value = file ? file.name : '';
      setResponses((prev) => ({
        ...prev,
        [qId]: { ...prev[qId], selected_options: prev[qId]?.selected_options ?? [], custom_text: value },
      }));
      if (!file) {
        if (qId === 5) {
          setPhotoFileUrl(null);
          setUploadingPhoto(false);
        }
        if (qId === 53) {
          setResumeFileUrl(null);
          setUploadingResume(false);
        }
        return;
      }
      const type = qId === 5 ? 'photo' : 'resume';
      if (qId === 5) setUploadingPhoto(true);
      if (qId === 53) setUploadingResume(true);
      const form = new FormData();
      form.set('file', file);
      form.set('type', type);
      fetch('/api/upload', { method: 'POST', body: form })
        .then((res) => (res.ok ? res.json() : Promise.reject(new Error('Upload failed'))))
        .then((data: { url?: string }) => {
          if (data.url) {
            if (qId === 5) setPhotoFileUrl(data.url);
            if (qId === 53) setResumeFileUrl(data.url);
          }
        })
        .catch(() => {
          if (qId === 5) setPhotoFileUrl(null);
          if (qId === 53) setResumeFileUrl(null);
        })
        .finally(() => {
          if (qId === 5) setUploadingPhoto(false);
          if (qId === 53) setUploadingResume(false);
        });
    },
    []
  );

  const canSend = useCallback(() => {
    if (question.id === 5) {
      if (uploadingPhoto) return false;
      if (currentResponse.custom_text && !photoFileUrl) return false;
    }
    if (question.id === 53) {
      if (uploadingResume) return false;
      if (currentResponse.custom_text && !resumeFileUrl) return false;
    }
    if (question.scored) {
      return question.multi_select
        ? selected.length >= 1 && selected.length <= 2
        : selected.length === 1;
    }
    if (question.required && [1, 2, 4, 6, 7, 9].includes(question.id)) {
      return (customText ?? '').trim().length > 0;
    }
    return true;
  }, [question, selected.length, customText, uploadingPhoto, uploadingResume, currentResponse.custom_text, photoFileUrl, resumeFileUrl]);

  const sendAndNext = useCallback(() => {
    if (!canSend() && question.scored) return;
    if (question.id === 5 || question.id === 53) {
      if (!currentResponse.custom_text) return;
    }
    const currentStep = step;
    const questionText = question.text;
    const userAnswer = formatUserAnswer(
      question.id,
      responses[question.id],
      (qid, ids) => getOptionLabels(qid, ids)
    );

    if (step < TOTAL - 1) setStep((s) => s + 1);
    else setStep(TOTAL);

    // Optional: fetch AI-generated transition (when OPENAI_API_KEY is set)
    fetch('/api/chat-transition', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ questionText, userAnswer: userAnswer || '—' }),
    })
      .then((res) => res.json())
      .then((data: { transition?: string | null }) => {
        if (data?.transition && typeof data.transition === 'string') {
          setAiTransitions((prev) => ({ ...prev, [currentStep]: data.transition! }));
        }
      })
      .catch(() => {});
  }, [canSend, question, currentResponse.custom_text, step, responses]);

  useEffect(() => {
    if (step < TOTAL || completionSubmitted.current) return;
    const email = responses[4]?.custom_text?.trim();
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return;
    completionSubmitted.current = true; // guard before any async work to prevent double submit
    if (!idempotencyKeyRef.current) {
      idempotencyKeyRef.current = typeof crypto !== 'undefined' && crypto.randomUUID
        ? crypto.randomUUID()
        : `idem-${Date.now()}-${Math.random().toString(36).slice(2)}`;
    }
    setSubmitStatus('loading');
    setEmailStatus('unknown');
    const payload = {
      email: email.toLowerCase(),
      responses: questions.map((q) => ({
        question_id: q.id,
        selected_options: responses[q.id]?.selected_options ?? [],
        custom_text: responses[q.id]?.custom_text,
      })),
      ...(photoFileUrl && { photo_file_url: photoFileUrl }),
      ...(resumeFileUrl && { resume_file_url: resumeFileUrl }),
    };
    const headers: Record<string, string> = { 'Content-Type': 'application/json' };
    if (idempotencyKeyRef.current) headers['Idempotency-Key'] = idempotencyKeyRef.current;
    fetch('/api/submit', {
      method: 'POST',
      headers,
      body: JSON.stringify(payload),
    })
      .then(async (res) => {
        const text = await res.text();
        if (!res.ok) {
          let msg = res.statusText;
          try {
            const d = JSON.parse(text);
            if (d && typeof d.error === 'string') msg = d.error;
            if (d && typeof d.session_id === 'string') {
              lastSessionIdRef.current = d.session_id;
              setLastSessionIdForRetry(d.session_id);
            }
          } catch {
            msg = text.length > 500 ? `${text.slice(0, 500)}…` : text || msg;
          }
          throw new Error(msg);
        }
        try {
          return JSON.parse(text) as { pdf_url?: string; email_status?: 'sent' | 'skipped' | 'failed'; session_id?: string };
        } catch {
          throw new Error('Invalid response');
        }
      })
      .then((data: { pdf_url?: string; email_status?: 'sent' | 'skipped' | 'failed'; session_id?: string }) => {
        if (data.session_id) lastSessionIdRef.current = data.session_id;
        setPdfUrl(data.pdf_url ?? null);
        setSubmitStatus('done');
        const status = data.email_status ?? 'unknown';
        setEmailStatus(status === 'sent' || status === 'skipped' || status === 'failed' ? status : 'unknown');
      })
      .catch((err: Error) => {
        setSubmitError(err?.message ?? 'Request failed');
        setSubmitStatus('error');
      });
  }, [step, responses, photoFileUrl, resumeFileUrl, submitTrigger]);

  const goBack = useCallback(() => {
    if (step > 0) setStep((s) => s - 1);
  }, [step]);

  const transitionPhrases = ['Got it.', 'Thanks.', 'Noted.', 'Next:', 'Alright.', 'Perfect.'];
  const getTransition = (index: number) => transitionPhrases[index % transitionPhrases.length];

  const buildMessages = useCallback((): ChatMessage[] => {
    const list: ChatMessage[] = [];
    const welcome = "Hi! I'm your Career Decoder. We'll go through a few questions so we can build your personalized PowerPrint™ report. Let's start.";
    list.push({ role: 'assistant', content: welcome });
    for (let i = 0; i < step; i++) {
      const q = questions[i];
      list.push({ role: 'assistant', content: getChatPrompt(q), questionId: q.id });
      const answer = formatUserAnswer(q.id, responses[q.id], (qid, ids) => getOptionLabels(qid, ids));
      list.push({ role: 'user', content: answer || '—' });
      const transitionText = aiTransitions[i] ?? getTransition(i);
      list.push({ role: 'assistant', content: transitionText, isTransition: true });
    }
    if (step < TOTAL) {
      list.push({ role: 'assistant', content: getChatPrompt(question), questionId: question.id });
    }
    return list;
  }, [step, question, responses, aiTransitions]);

  const messages = buildMessages();

  if (step >= TOTAL) {
    return (
      <main className={styles.root}>
        <div className={styles.container}>
          <div className={styles.header}>
            <span className={styles.headerTitle}>Career Decoder</span>
            <span className={styles.progressBadge}>Complete</span>
          </div>
          <div className={styles.messages}>
            {messages.map((m, i) => {
              const isTransition = m.role === 'assistant' && 'isTransition' in m && (m as { isTransition?: boolean }).isTransition;
              return (
                <div
                  key={`complete-msg-${i}-${m.role}`}
                  className={`${styles.bubbleRow} ${m.role === 'user' ? styles.bubbleRowUser : ''}`}
                >
                  <div className={styles.bubbleCell}>
                    <span className={m.role === 'user' ? styles.avatarUser : styles.avatarBot}>
                      {m.role === 'user' ? 'You' : 'CD'}
                    </span>
                    <div className={`${styles.bubble} ${m.role === 'user' ? styles.bubbleUser : isTransition ? styles.bubbleTransition : styles.bubbleBot}`}>
                      {m.content}
                    </div>
                  </div>
                </div>
              );
            })}
            {submitStatus === 'loading' && (
              <div className={styles.bubbleRow}>
                <div className={styles.bubbleCell}>
                  <span className={styles.avatarBot}>CD</span>
                  <div className={`${styles.bubble} ${styles.bubbleBot} ${styles.loadingBubble}`}>
                    <span>Saving your results</span>
                    <div className={styles.loadingDots}>
                      <span /><span /><span />
                    </div>
                  </div>
                </div>
              </div>
            )}
            {submitStatus === 'error' && (
              <div className={styles.bubbleRow}>
                <div className={styles.bubbleCell}>
                  <span className={styles.avatarBot}>CD</span>
                  <div className={`${styles.bubble} ${styles.bubbleBot} ${styles.bubbleError}`}>
                    <p>Something went wrong: {submitError}.</p>
                    <p style={{ marginTop: 8 }}>
                      <button type="button" onClick={() => { completionSubmitted.current = false; setSubmitStatus('loading'); setSubmitTrigger((t) => t + 1); }} className={styles.link} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 0, font: 'inherit', color: 'inherit', textDecoration: 'underline' }}>
                        Retry submission
                      </button>
                      {lastSessionIdForRetry && (
                        <>
                          {' · '}
                          <button type="button" onClick={() => {
                            setSubmitStatus('loading');
                            fetch('/api/submit/retry-report', {
                              method: 'POST',
                              headers: { 'Content-Type': 'application/json' },
                              body: JSON.stringify({ session_id: lastSessionIdForRetry }),
                            }).then(async (r) => {
                              const data = await r.json();
                              if (r.ok) {
                                setPdfUrl(data.pdf_url ?? null);
                                setSubmitStatus('done');
                                setEmailStatus(data.email_status ?? 'unknown');
                              } else {
                                setSubmitError(data?.error ?? 'Retry failed');
                              }
                            }).catch(() => setSubmitError('Retry failed'));
                          }} className={styles.link} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 0, font: 'inherit', color: 'inherit', textDecoration: 'underline' }}>
                            Retry report only
                          </button>
                        </>
                      )}
                      {' '}Or contact support.
                    </p>
                  </div>
                </div>
              </div>
            )}
            {submitStatus === 'done' && (
              <div className={styles.bubbleRow}>
                <div className={styles.bubbleCell}>
                  <span className={styles.avatarBot}>CD</span>
                  <div className={`${styles.bubble} ${styles.completionBubble}`}>
                    <p><strong>All set! We’ve got your Career Decoder form.</strong></p>
                    <p style={{ marginTop: 12 }}>
                      Next: we’ll build out your custom PowerPrint™ — with career matches, job market info, skills to focus on, and insight into how you’re wired for work.
                    </p>
                    <p style={{ marginTop: 12 }}>🧠 It’s not auto-generated. It’s personalized — by a real coach who gets it.</p>
                    <p style={{ marginTop: 12 }}>
                      You’ll hear from us soon.
                    
                    </p>
                    <p style={{ marginTop: 12 }}>
                      Have questions? Email us at{' '}
                      <a href="mailto:bianca@bianomics.com" className={styles.link}>bianca@bianomics.com</a>.
                    </p>
                    {pdfUrl && (
                      <p style={{ marginTop: 12 }}>
                        <a href={pdfUrl} target="_blank" rel="noopener noreferrer" className={styles.link}>
                          Download your report (PDF)
                        </a>
                      </p>
                    )}
                    <p style={{ marginTop: 12 }}>
                      <Link href="/" className={styles.link}>Back to home</Link>
                    </p>
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
        </div>
      </main>
    );
  }

  return (
    <main className={styles.root}>
      <div className={styles.container}>
        <div className={styles.header}>
          <span className={styles.headerTitle}>Career Decoder</span>
          <span className={styles.progressBadge}>Question {step + 1} of {TOTAL}</span>
        </div>
        <div className={styles.progressWrap}>
          <div className={styles.progressTrack}>
            <div className={styles.progressFill} style={{ width: `${progress}%` }} />
          </div>
        </div>

        <div className={styles.messages}>
          {messages.map((m, i) => {
            const isTransition = m.role === 'assistant' && 'isTransition' in m && (m as { isTransition?: boolean }).isTransition;
            return (
              <div
                key={`msg-${i}-${m.role}-${typeof m.content === 'string' ? m.content.slice(0, 30) : ''}`}
                className={`${styles.bubbleRow} ${m.role === 'user' ? styles.bubbleRowUser : ''}`}
              >
                <div className={styles.bubbleCell}>
                  <span className={m.role === 'user' ? styles.avatarUser : styles.avatarBot}>
                    {m.role === 'user' ? 'You' : 'CD'}
                  </span>
                  <div className={`${styles.bubble} ${m.role === 'user' ? styles.bubbleUser : isTransition ? styles.bubbleTransition : styles.bubbleBot}`}>
                    {m.content}
                  </div>
                </div>
              </div>
            );
          })}
          <div ref={messagesEndRef} />
        </div>

        <div className={styles.inputArea}>
          {question.scored && optionsWithLabels.length > 0 ? (
            <>
              <div className={styles.optionsRow}>
                {optionsWithLabels.map((opt) => {
                  const isSelected = selected.includes(opt.id);
                  const isRadio = !question.multi_select;
                  return (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => {
                        handleSelect(opt.id);
                        if (isRadio) setTimeout(sendAndNext, 120);
                      }}
                      className={`${styles.optionChip} ${isSelected ? styles.optionChipSelected : ''}`}
                    >
                      {isRadio ? '○' : (isSelected ? '☑' : '☐')} {opt.label}
                    </button>
                  );
                })}
              </div>
              {question.multi_select && (
                <p className={styles.hint}>Select up to 2, then send. Selected: {selected.length}</p>
              )}
              <div className={styles.inputRow}>
                <input
                  type="text"
                  placeholder="Add a note (optional)"
                  value={customText}
                  onChange={(e) => handleTextChange(e.target.value)}
                  className={styles.textInput}
                />
                <button
                  type="button"
                  onClick={sendAndNext}
                  disabled={!canSend()}
                  className={styles.sendBtn}
                >
                  Send
                </button>
              </div>
            </>
          ) : (
            <>
              {question.id === 7 ? (
                <div className={styles.inputRow} style={{ alignItems: 'flex-end' }}>
                  <textarea
                    placeholder="Type your answer..."
                    value={customText}
                    onChange={(e) => handleTextChange(e.target.value)}
                    rows={3}
                    className={styles.textArea}
                  />
                  <button
                    type="button"
                    onClick={sendAndNext}
                    disabled={!canSend()}
                    className={styles.sendBtn}
                  >
                    Send
                  </button>
                </div>
              ) : question.id === 5 || question.id === 53 ? (
                <div className={styles.fileZone}>
                  <input
                    type="file"
                    id={`file-${question.id}`}
                    accept={question.id === 5 ? 'image/*' : '.pdf,.doc,.docx'}
                    onChange={(e) => handleFileChange(e, question.id)}
                    className={styles.fileInput}
                  />
                  <label htmlFor={`file-${question.id}`} className={styles.fileLabel}>
                    {question.id === 5 ? (uploadingPhoto ? 'Uploading…' : 'Upload photo') : (uploadingResume ? 'Uploading…' : 'Upload resume')}
                  </label>
                  {customText && <span className={styles.fileName}>{customText}</span>}
                  <button
                    type="button"
                    onClick={sendAndNext}
                    disabled={!canSend()}
                    className={styles.sendBtn}
                  >
                    Send
                  </button>
                </div>
              ) : (
                <div className={styles.inputRow}>
                  <input
                    type={question.id === 4 ? 'email' : 'text'}
                    placeholder="Type your answer..."
                    value={customText}
                    onChange={(e) => handleTextChange(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && canSend() && sendAndNext()}
                    className={styles.textInput}
                  />
                  <button
                    type="button"
                    onClick={sendAndNext}
                    disabled={!canSend()}
                    className={styles.sendBtn}
                  >
                    Send
                  </button>
                </div>
              )}
            </>
          )}

          {step > 0 && (
            <button type="button" onClick={goBack} className={styles.backLink}>
              ← Previous question
            </button>
          )}
        </div>
      </div>
    </main>
  );
}
