#!/bin/bash
# Run this ON THE SERVER after uploading deploy.tar and .env.local to this folder.
# Usage: chmod +x setup-and-run.sh && ./setup-and-run.sh

set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR"

echo "=== 1. Node.js 20 + PM2 (if missing) ==="
if ! command -v node &>/dev/null; then
  curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
  sudo apt-get install -y nodejs
fi
if ! command -v pm2 &>/dev/null; then
  sudo npm install -g pm2
fi
node -v
pm2 -v

echo ""
echo "=== 2. Extract and env ==="
test -f deploy.tar && tar -xf deploy.tar || { echo "deploy.tar not found in $DIR"; exit 1; }
mkdir -p logs
test -f .env.local || cp .env.server.example .env.local 2>/dev/null || true

echo ""
echo "=== 3. Firewall (port 3000) ==="
sudo ufw allow 3000/tcp 2>/dev/null || true

echo ""
echo "=== 4. Install, build, start ==="
npm install
npm run build
pm2 delete career-assessment 2>/dev/null || true
pm2 start ecosystem.config.cjs
pm2 save

echo ""
echo "=== 5. Status ==="
pm2 status
ss -tlnp 2>/dev/null | grep 3000 || true

echo ""
echo ">>> Open: http://38.97.62.139:3000"
echo ">>> (If refused, open inbound TCP 3000 in cloud firewall.)"
